import apache_beam as beam
import csv
from datetime import datetime

def parse_method(row):
    """
    Función para convertir cada fila a formato de diccionario
    y establecer el tipo correcto para cada columna
    """
    # date_format = '%Y-%m-%d %H:%M:%S.%f'
    parsed_row = {}
    parsed_row['id'] = int(row[0])
    parsed_row['job'] = str(row[1])
    # parsed_row['datetime'] = datetime.strptime(row[2], date_format)
    # parsed_row['department_id'] = int(row[3])
    # parsed_row['job_id'] = int(row[4])
    return parsed_row

def validate_schema(element):
    """
    Función para validar que el elemento tenga el número correcto de columnas
    """
    # Reemplazar con el número de columnas esperado en el archivo CSV
    expected_num_fields = 2
    num_fields = len(element)
    if num_fields != expected_num_fields:
        raise ValueError(f'Número incorrecto de columnas. Esperado: {expected_num_fields}, encontrado: {num_fields}')
    return True

def validate_type(element):
    """
    Función para validar que los tipos de datos sean correctos
    """
    try:
        int(element[0])
        str(element[1])
        # datetime.strptime(element[2], '%Y-%m-%d %H:%M:%S.%f')
        # int(element[3])
        # int(element[4])
        return True
    except ValueError:
        raise ValueError('Tipo de dato incorrecto. Revisar el archivo CSV')

PROJECT_ID = 'bigdatamigration-382020'
BUCKET_NAME = 'bucket_migracion_raw'
TABLE_NAME = 'jobs'

# Establecer opciones de conexión a Cloud SQL
connection_config = {
    'database': 'bdmigracion',
    'user': 'sqlserver',
    'password': 'Jgiperu1#',
    'driver': 'SQL Server Native Client 11.0',
    'host': 'sqlserver',
}

table_schema = {
    'id': 'INTEGER',
    'name': 'VARCHAR(255)'
}

def run():
    with beam.Pipeline() as p:
        # Leer archivos CSV desde un bucket de GCS
        lines = p | 'ReadFromGCS' >> beam.io.ReadFromText(f'gs://{BUCKET_NAME}/trabajos/*.csv', skip_header_lines=1)

        # Parsear cada fila y convertirla a formato de diccionario
        records = lines | 'ParseCSV' >> beam.Map(lambda row: next(csv.reader([row]))) \
                        | 'ValidateSchema' >> beam.Filter(validate_schema) \
                        | 'ValidateType' >> beam.Filter(validate_type) \
                        | 'ParseToDict' >> beam.Map(parse_method)

        # Escribir los registros en Cloud SQL
        records | 'WriteToCloudSQL' >> beam.io.WriteToCloudSQL(
            table=TABLE_NAME,
            connection_config=connection_config,
            batch_size=100,
            table_schema=table_schema
        )

if __name__ == '__main__':
    run()